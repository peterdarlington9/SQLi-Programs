#!/bin/bash
cat /tmp/mongo.nosql | mongosh "mongodb://root:prisma@mongo:27017"