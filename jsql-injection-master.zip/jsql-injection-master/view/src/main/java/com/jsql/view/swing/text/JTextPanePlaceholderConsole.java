package com.jsql.view.swing.text;

/**
 * Textfield with information text displayed when empty.
 */
@SuppressWarnings("serial")
public class JTextPanePlaceholderConsole extends JTextPanePlaceholder {

    public JTextPanePlaceholderConsole(String placeholder) {
        super(placeholder);
    }
}