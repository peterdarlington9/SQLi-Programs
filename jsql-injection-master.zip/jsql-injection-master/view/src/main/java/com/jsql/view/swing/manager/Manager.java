package com.jsql.view.swing.manager;

public interface Manager {

}
